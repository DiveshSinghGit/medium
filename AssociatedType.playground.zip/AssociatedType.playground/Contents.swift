protocol UserDataBase {
    associatedtype DataType

    var items: [DataType] { get set}
    mutating func add(item: DataType)
}
extension UserDataBase {
    mutating func add(item: DataType) {
        items.append(item)
    }
}

struct NameDatabase: UserDataBase {
    var items = [String]()
}

struct AgeDatabase: UserDataBase {
    var items = [Int]()
}

var names = NameDatabase()
    names.add(item: "Divesh")
    names.add(item: "Sujeet")

var ages =  AgeDatabase()
    ages.add(item: 35)
    ages.add(item: 36)

